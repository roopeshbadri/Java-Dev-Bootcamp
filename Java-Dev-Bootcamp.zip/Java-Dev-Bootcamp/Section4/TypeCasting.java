public class TypeCasting {
    public static void main(String[] args) {
        int ants=2000;
        int purchasedBlockofCheese=1;
        System.out.println("There are "+ ants+ "and "+ purchasedBlockofCheese+"block of cheese");
        System.out.println("Each ant carried "+((double)purchasedBlockofCheese/ants) + "from the total amount of cheese");
        double salary=5423.94;
        int roundedSalary=(int)salary;
        System.out.println("My monthly salary is: "+roundedSalary);
        System.out.println(2/5);
    }
}
