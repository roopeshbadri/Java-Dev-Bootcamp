public class JoiningStrings {
    public static void main(String[] args) {
        int year=2010;
        String winner="Spain";
        String announcement="The winner of " + year + " FIFA World Cup is" + winner;
        System.out.println(announcement);  
    }
}
