package Section6;

public class ComparingStrings {
    public static void main(String[] args) {
        String word = "hello";
        String secondWord="hello";
        System.out.println(word.equals(secondWord));
        String word3 = "heyy";
        String word4 = "goodbye";
        System.out.println(!word3.equals(word4));
    }
}
